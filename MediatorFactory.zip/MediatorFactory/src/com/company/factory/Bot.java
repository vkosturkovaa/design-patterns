package com.company.factory;

import com.company.mediator.ChatRoom;

public class Bot extends User{

    public void checkForCat(User user, String message) {
        if(message.equals("cat")) {
            ChatRoom.history.remove(user);
            System.out.println("Cat is not allowed in chatRoom");
        }
    }
}
