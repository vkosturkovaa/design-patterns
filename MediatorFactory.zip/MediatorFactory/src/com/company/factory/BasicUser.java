package com.company.factory;

public class BasicUser extends User {
}
