package com.company.factory;

public class UserFactory {

    public static User getUser(String userType) {

        if (userType == null) {
            return new User();
        }

        if (userType.equalsIgnoreCase("user")) {
            return new BasicUser();
        }

        if (userType.equalsIgnoreCase("bot")) {
            return new Bot();
        }

        return null;
    }

}
