package com.company.mediator;

import com.company.factory.Bot;
import com.company.factory.User;
import com.company.factory.UserFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class ChatRoom {

    private static Bot bot = null;

    public static Map<User, List<String>> history = new HashMap<>();

    public static void sendMessage(User user, String message){
        System.out.println(LocalDateTime.now() + " [" + user.getName() + "] : " + message);


        history.putIfAbsent(user, List.of(message));
        List<String> userMessages = new ArrayList<>(history.get(user));
        userMessages.add(message);
        history.replace(user, userMessages);

        if(bot != null) {
            bot.checkForCat(user,message);
        }

        if (message.equalsIgnoreCase("addBot")) {
            User newBot = UserFactory.getUser("bot");
            bot = (Bot) newBot;
        }

    }
}
