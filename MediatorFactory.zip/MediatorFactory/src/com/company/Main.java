package com.company;

import com.company.factory.User;
import com.company.factory.UserFactory;
import com.company.mediator.ChatRoom;

public class Main {

    public static void main(String[] args) {
        User user1 = UserFactory.getUser("user");
        user1.setName("John");
        User user2 = UserFactory.getUser("user");
        user2.setName("Nicolas");
        User user3 = UserFactory.getUser("user");
        user3.setName("Peter");

        ChatRoom.sendMessage(user1, "Hello I am user1");
        ChatRoom.sendMessage(user2, "Hello I am user2");
        ChatRoom.sendMessage(user3, "Hello I am user3");

        ChatRoom.sendMessage(user1, "Hello I will add bot");
        ChatRoom.sendMessage(user1, "addBot");
        ChatRoom.sendMessage(user2, "Okey what does Bot do?");
        ChatRoom.sendMessage(user3, "When you write 'cat' it removes you from chat");
        ChatRoom.sendMessage(user2, "No way");
        ChatRoom.sendMessage(user2, "cat");

        System.out.println("Users remaining: ");
        ChatRoom.history
                .keySet()
                .forEach(System.out::println);

        ChatRoom.sendMessage(user1, "Told you");
    }
}
