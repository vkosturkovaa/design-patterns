package com.company;

import com.company.command.LayDownOrder;
import com.company.command.Order;
import com.company.command.StandUpOrder;
import com.company.observer.*;

public class Main {

    public static void main(String[] args) {

        Person inHomeUser = new Person();
        Observer homeObserver = new HomeObserver(inHomeUser);
        Person inHomeUser2 = new Person();
        Observer homeObserver2 = new HomeObserver(inHomeUser2);
        Person inHomeUser3 = new Person();
        Observer homeObserver3 = new HomeObserver(inHomeUser3);

        Person inPersonUser = new Person();
        Observer inPersonObserver = new InPersonObserver(inPersonUser);

        inPersonUser.attach(homeObserver);
        inPersonUser.attach(homeObserver2);
        inPersonUser.attach(homeObserver3);

        Order layDownOrder = new LayDownOrder(inPersonUser);
        Order standUpOrder = new StandUpOrder(inPersonUser);

        Instructor instructor = new Instructor();

        instructor.takeOrders(layDownOrder);
        instructor.takeOrders(standUpOrder);

        instructor.giveOrder();
    }
}
