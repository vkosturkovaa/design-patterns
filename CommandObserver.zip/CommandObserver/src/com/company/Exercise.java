package com.company;

public enum Exercise {
    LAY, STAND
}
