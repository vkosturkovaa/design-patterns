package com.company.command;

import com.company.observer.Person;

public class StandUpOrder implements Order {
    private Person trainee;

    public StandUpOrder(Person trainee) {
        this.trainee = trainee;
    }

    @Override
    public void takeOrders() {
        trainee.standUp();
    }
}
