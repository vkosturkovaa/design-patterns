package com.company.command;

public interface Order {
    void takeOrders();
}
