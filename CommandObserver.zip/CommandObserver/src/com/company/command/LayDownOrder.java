package com.company.command;

import com.company.observer.Person;

public class LayDownOrder implements Order {
    private Person trainee;

    public LayDownOrder(Person trainee) {
        this.trainee = trainee;
    }

    @Override
    public void takeOrders() {
        trainee.layDown();
    }
}
