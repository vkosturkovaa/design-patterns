package com.company.observer;

import com.company.Exercise;
import com.company.observer.Observer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Person {

    private int id = new Random().nextInt();

    private List<Observer> observers = new ArrayList<>();

    private Exercise exercise;

    public Exercise getExercise() {
        return exercise;
    }

    public void layDown() {
        this.exercise = Exercise.LAY;
        notifyAllObservers();
    }

    public void standUp() {
        this.exercise = Exercise.STAND;
        notifyAllObservers();
    }

    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void notifyAllObservers() {
        for (Observer observer : observers) {
            observer.changeExercise();
        }
    }

    @Override
    public String toString() {
        return "Person{" + id + '}';
    }
}
