package com.company.observer;

public abstract class Observer {
    protected Person person;
    public abstract void changeExercise();
}
