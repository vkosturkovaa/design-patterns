package com.company.observer;

import com.company.Exercise;

public class HomeObserver extends Observer {

    public HomeObserver(Person person) {
        this.person = person;
        this.person.attach(this);
    }

    @Override
    public void changeExercise() {
        System.out.println("Change exercise watching trainee and changing exercise to: " + person.toString());
    }
}
