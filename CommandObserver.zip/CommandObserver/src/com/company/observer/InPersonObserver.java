package com.company.observer;

public class InPersonObserver extends Observer{

    public InPersonObserver(Person person) {
        this.person = person;
        this.person.attach(this);
    }

    @Override
    public void changeExercise() {
        System.out.println("Change exercise watching instructor to: " + person.getExercise() + "-" + person.toString());
    }
}
