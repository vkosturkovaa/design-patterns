package com.company.observer;

import com.company.command.Order;

import java.util.ArrayList;
import java.util.List;

public class Instructor {

    private List<Order> orderList = new ArrayList<Order>();

    public void takeOrders(Order order) {
        this.orderList.add(order);
    }

    public void giveOrder() {
        for (Order order : orderList) {
            order.takeOrders();
        }
    }
}
