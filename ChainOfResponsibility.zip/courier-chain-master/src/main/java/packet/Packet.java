package packet;

public interface Packet {

}
