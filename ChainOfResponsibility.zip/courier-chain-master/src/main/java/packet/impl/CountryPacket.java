package packet.impl;

import packet.Packet;

public class CountryPacket implements Packet {
}
