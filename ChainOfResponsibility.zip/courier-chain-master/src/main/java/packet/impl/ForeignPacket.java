package packet.impl;

import packet.Packet;

public class ForeignPacket implements Packet {
}
