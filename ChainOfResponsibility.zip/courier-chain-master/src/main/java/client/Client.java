package client;

public interface Client {

    void requestSendPacket();

    void requestReceivePacket();

}
