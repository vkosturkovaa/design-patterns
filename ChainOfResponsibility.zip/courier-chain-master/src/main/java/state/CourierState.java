package state;

public enum CourierState {
    FREE,
    PROCESSING
}
